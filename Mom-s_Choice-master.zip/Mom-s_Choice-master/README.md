# Mom-s_Choice
Online Kids Accessories shop Assignment using basic HTML, CSS, javascript, and Php.

Group members

L.C.R Karunathunge
S.L Abeygunawardana
R.M.K.D.Kumarasirii
D.A.Devindi Madubashini
E.D.M Silva

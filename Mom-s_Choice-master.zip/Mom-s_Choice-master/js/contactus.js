function popup()
{
	alert("Your message has submitted successfully.");
	window.open("#");
}

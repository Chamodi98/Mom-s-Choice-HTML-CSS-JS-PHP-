
function linkpages1()
{
alert("successful the payment");
window.open("AdminDashboard.html");
}

function linkpages2()
{
window.open("index.php");
}
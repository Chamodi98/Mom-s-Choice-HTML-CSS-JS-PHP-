function validate()
{
alert("successful");
  window.open("index.php");
}
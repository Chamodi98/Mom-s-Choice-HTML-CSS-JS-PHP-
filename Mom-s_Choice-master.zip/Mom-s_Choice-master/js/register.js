
function checkPassword(){
	if(document.getElementById("pwd").value != document.getElementById("cnfpwd").value)
	{
		alert("Two passwords are dismatched!!");
		
		
	}
	else
		{
		alert("Successful!!");
		
	}
}
